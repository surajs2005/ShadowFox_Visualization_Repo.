
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("countries of the world.csv", decimal=",")
df.columns = [col.strip().replace(' ', '_') for col in df.columns]
df.dropna(inplace=True)

# Bar Chart: Top 10 Countries by GDP
top10_gdp = df.sort_values(by="GDP_($_per_capita)", ascending=False).head(10)
plt.bar(top10_gdp["Country"], top10_gdp["GDP_($_per_capita)"])
plt.title("Top 10 Countries by GDP per Capita")
plt.xticks(rotation=45)
plt.ylabel("GDP ($)")
plt.tight_layout()
plt.savefig("outputs/top10_gdp_bar.png")
plt.clf()

# Pie Chart: Continents by Country Count
continent_counts = df['Region'].value_counts()
plt.pie(continent_counts, labels=continent_counts.index, autopct='%1.1f%%')
plt.title("Country Distribution by Region")
plt.axis('equal')
plt.savefig("outputs/region_pie_chart.png")
plt.clf()

# Line Chart: Population vs. GDP (Top 10)
top10_pop = df.sort_values(by="Population", ascending=False).head(10)
plt.plot(top10_pop["Country"], top10_pop["Population"], label="Population")
plt.plot(top10_pop["Country"], top10_pop["GDP_($_per_capita)"] * 1000, label="GDP (scaled)")
plt.title("Top 10 Countries: Population vs GDP")
plt.xticks(rotation=45)
plt.legend()
plt.tight_layout()
plt.savefig("outputs/pop_vs_gdp_line.png")
plt.clf()

# Scatter Plot: Literacy vs GDP
sns.scatterplot(data=df, x="Literacy_(%)", y="GDP_($_per_capita)", hue="Region")
plt.title("Literacy Rate vs GDP per Capita by Region")
plt.savefig("outputs/literacy_vs_gdp_scatter.png")
plt.clf()

# Histogram: Literacy Rate Distribution
sns.histplot(df["Literacy_(%)"], bins=20, kde=True)
plt.title("Distribution of Literacy Rate")
plt.xlabel("Literacy (%)")
plt.savefig("outputs/literacy_histogram.png")
plt.clf()

# Box Plot: GDP by Region
sns.boxplot(data=df, x="Region", y="GDP_($_per_capita)")
plt.xticks(rotation=90)
plt.title("GDP per Capita by Region")
plt.tight_layout()
plt.savefig("outputs/gdp_by_region_boxplot.png")
plt.clf()

# Heatmap: Feature Correlation
corr = df.select_dtypes(include='number').corr()
sns.heatmap(corr, annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.savefig("outputs/correlation_heatmap.png")
plt.clf()
