# ShadowFox Visualization Project

Beginner-level project using Matplotlib and Seaborn with the 'Countries of the World' dataset.

## Visualizations Included:
1. Bar Chart – Top 10 Countries by GDP per Capita
2. Pie Chart – Country Count by Region
3. Line Chart – Population vs GDP for Top 10 Countries
4. Scatter Plot – Literacy vs GDP
5. Histogram – Literacy Distribution
6. Box Plot – GDP by Region
7. Heatmap – Feature Correlation

## How to Run:
pip install -r requirements.txt
python shadowfox_visualization_script.py
